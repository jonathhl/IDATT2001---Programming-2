package edu.ntnu.jonathhl.idatt2001;

import edu.ntnu.jonathhl.idatt2001.utility.FileHandler;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.io.IOException;

public class FileHandlerTest {

    @Test
    @DisplayName("Reading file reads all lines")
    void testReadingFileReadsAllLines() {
        var fileHandler = new FileHandler();
        try {
            fileHandler.readFile();
        } catch (IOException e) {
            e.printStackTrace();
        }
        // The list should have exactly 5132 non-empty lines in total
        assertEquals(fileHandler.getList().size(), 5131);
    }

    @Test
    @DisplayName("Test if method can see if file is empty or not")
    void testIfMethodCanSeeIfFileIsEmptyOrNot() {
        var fileHandler = new FileHandler();

        assertFalse(fileHandler.getList().size() < 0);
    }
}
