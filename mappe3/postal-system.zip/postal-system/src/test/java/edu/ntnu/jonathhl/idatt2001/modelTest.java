package edu.ntnu.jonathhl.idatt2001;

import edu.ntnu.jonathhl.idatt2001.model.ZipInfo;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class modelTest {

    // Negative test
    @Test
    @DisplayName("Zip object throws exception if postal code is wrong length")
    void testZipObjectThrowsExceptionIfPostalCodeIsIncorrect() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            var object = new ZipInfo("test", "1", "1111", "test", "P");
        });

        String expectedMessage = "Either the postal code or the municipality code are too short";
        String actualMessage = exception.getMessage();

        assertTrue(actualMessage.contains(expectedMessage));
    }

    // Positive test
    @Test
    @DisplayName("Zip object gets added if postal code is correct length")
    void testZipObjectGetsAddedIfPostalCodeIsCorrectLength() {
        var object = new ZipInfo("test", "1111", "1111", "test", "P");

        assertFalse(object.getPostalCode().isEmpty());
    }

    // Negative test
    @Test
    @DisplayName("Zip object throws exception if municipality code is wrong length")
    void testZipObjectThrowsExceptionIfMunicipalityCodeIsIncorrect() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            var object = new ZipInfo("test", "1111", "1", "test", "P");
        });

        String expectedMessage = "Either the postal code or the municipality code are too short";
        String actualMessage = exception.getMessage();

        assertTrue(actualMessage.contains(expectedMessage));
    }

    // Positive test
    @Test
    @DisplayName("Zip object gets added if municipality code is correct length")
    void testZipObjectGetsAddedIfMunicipalityCodeIsCorrectLength() {
        var object = new ZipInfo("test", "1111", "1111", "test", "P");

        assertFalse(object.getMunicipalityCode().isEmpty());
    }
}
