package edu.ntnu.jonathhl.idatt2001.factory;

import javafx.scene.control.ButtonType;
import javafx.scene.control.Dialog;

/**
 * Factory dedicated to creating popup windows. Used to relay messages to user.
 *
 * @author jonathhl
 */
public class DialogFactory {

    // Private constructor to hide the public one
    private DialogFactory() {
    }

    /**
     * Method to define the dialog window types.
     * 
     * @param title
     *            defines the title of the window
     * @param header
     *            defines the header of the window
     * @param content
     *            defines the actual content. Will frequently have exception messages.
     * @param buttonType
     *            the type of buttons to show
     * 
     * @return returns a skeleton for other dialog box methods to use.
     */
    public static Dialog<ButtonType> getDialog(String title, String header, String content, ButtonType[] buttonType) {
        Dialog<ButtonType> dialog = new Dialog<>();
        dialog.setTitle(title);
        dialog.setHeaderText(header);
        dialog.setContentText(content);

        dialog.getDialogPane().getButtonTypes().addAll(buttonType);

        return dialog;
    }

    /**
     * Dialog window only to relay messages.
     * 
     * @param title
     *            the title
     * @param header
     *            the header
     * @param content
     *            the content
     * 
     * @return returns a dialog window with only an OK button.
     */
    public static Dialog<ButtonType> getOKDialog(String title, String header, String content) {
        return getDialog(title, header, content, new ButtonType[] { ButtonType.OK });
    }

    /**
     * Dialog window with several use areas.
     * 
     * @param title
     *            the title
     * @param header
     *            the header
     * @param content
     *            the content
     * 
     * @return returns a dialog window with yes or no choices.
     */
    public static Dialog<ButtonType> getYesNoDialog(String title, String header, String content) {
        return getDialog(title, header, content, new ButtonType[] { ButtonType.YES, ButtonType.NO });
    }
}
