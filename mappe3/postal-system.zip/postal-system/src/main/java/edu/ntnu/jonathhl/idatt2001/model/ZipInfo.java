package edu.ntnu.jonathhl.idatt2001.model;

/**
 * Class containing all parametres of a Zip Code object
 *
 * @author jonathhl
 */
public class ZipInfo {

    public String postalArea;
    public String postalCode;
    public String municipalityCode;
    public String municipalityName;
    public String category;

    /**
     * Constructor for the zip code objects.
     * 
     * @param postalArea
     *            which area the zip code is located in.
     * @param postalCode
     *            the actual code.
     * @param municipalityCode
     *            which municipality code it has.
     * @param municipalityName
     *            which municipality area the code is located in.
     * @param category
     *            the category of the zip code.
     */
    public ZipInfo(String postalArea, String postalCode, String municipalityCode, String municipalityName,
            String category) {
        if (postalCode.length() == 4 && municipalityCode.length() == 4) {
            this.postalArea = postalArea;
            this.postalCode = postalCode;
            this.municipalityCode = municipalityCode;
            this.municipalityName = municipalityName;
            this.category = category;
        } else {
            throw new IllegalArgumentException("Either the postal code or the municipality code are too short");
        }
    }

    public String getPostalArea() {
        return postalArea;
    }

    public String getPostalCode() {
        return postalCode;
    }

    public String getMunicipalityCode() {
        return municipalityCode;
    }

    public String getMunicipalityName() {
        return municipalityName;
    }

    public String getCategory() {
        return category;
    }
}
