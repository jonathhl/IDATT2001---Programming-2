package edu.ntnu.jonathhl.idatt2001.controller;

import com.jfoenix.controls.JFXTextField;
import edu.ntnu.jonathhl.idatt2001.factory.DialogFactory;
import edu.ntnu.jonathhl.idatt2001.model.ListCleaner;
import edu.ntnu.jonathhl.idatt2001.model.ZipInfo;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.fxml.FXML;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

/**
 * Main controller class for the application
 *
 * @author jonathhl
 */
public class PostalRegistryController {

    @FXML
    private JFXTextField searchBar;
    @FXML
    private TableView<ZipInfo> registryPostalInfo;
    @FXML
    private TableColumn<ZipInfo, String> postalAreaColumn;
    @FXML
    private TableColumn<ZipInfo, String> postalCodeColumn;
    @FXML
    private TableColumn<ZipInfo, String> municipalityCodeColumn;
    @FXML
    private TableColumn<ZipInfo, String> municipalityNameColumn;
    @FXML
    private TableColumn<ZipInfo, String> categoryColumn;

    /**
     * Initialize method. It creates the observable list, and wraps it in a filtered list to finally getting wrapped in
     * a sorted list.
     */
    @FXML
    public void initialize() {
        /*
         * I chose to use a observable array because of future compability, in case the list gets expanded. I understand
         * that observable list can have an effect on the computers performance, in comparison to other list-types, but
         * i chose it anyway because i feel the payoff is greatly worth it.
         */
        ObservableList<ZipInfo> observablePostalCodeRegistry;

        // Creating columns
        this.postalAreaColumn.setCellValueFactory(new PropertyValueFactory<>("postalArea"));
        this.postalCodeColumn.setCellValueFactory(new PropertyValueFactory<>("postalCode"));
        this.municipalityCodeColumn.setCellValueFactory(new PropertyValueFactory<>("municipalityCode"));
        this.municipalityNameColumn.setCellValueFactory(new PropertyValueFactory<>("municipalityName"));
        this.categoryColumn.setCellValueFactory(new PropertyValueFactory<>("category"));

        // Creating list
        var listCleaner = new ListCleaner();
        observablePostalCodeRegistry = (FXCollections.observableArrayList(listCleaner.cleanup()));

        // ------------- Filter-logic ------------------
        // Wrapping the observable list in a filtered list
        FilteredList<ZipInfo> filteredList = new FilteredList<>(observablePostalCodeRegistry, l -> true);

        searchBar.textProperty().addListener((observable, oldValue, newValue) -> {
            filteredList.setPredicate(zipInfo -> {

                // If the search bar is empty, display all entries
                if (newValue == null || newValue.isEmpty()) {
                    return true;
                }

                String lowerCaseFilter = newValue.toLowerCase();

                // Checks if any variable matches the searched text
                if (zipInfo.getPostalCode().toLowerCase().contains(lowerCaseFilter)
                        || zipInfo.getPostalArea().toLowerCase().contains(lowerCaseFilter) {
                    return true;
                } else {
                    return false; // Nothing matches
                }
            });
        });

        // Wrapping the filtered list in a sorted list
        SortedList<ZipInfo> sortedList = new SortedList<>(filteredList);

        // Binds the sorted list comparator to the comparator already in the table view.
        sortedList.comparatorProperty().bind(registryPostalInfo.comparatorProperty());

        // Adding entries to the table
        registryPostalInfo.setItems(sortedList);
    }

    @FXML
    public void infoClick() {
        DialogFactory.getDialog("Information Dialog", "Category Types", "B: Both street addresses and mailboxes.\n"
                + "F: Other areas of use (Common).\n"
                + "G: Street addresses (and area addresses). Commonly known in Norway as \"Grønne Postkasser\" \n"
                + "P: Mail boxes.\n" + "S: Service postal codes. (not in use as postal addresses.",
                new ButtonType[] { ButtonType.OK }).show();
    }
}
