package edu.ntnu.jonathhl.idatt2001.factory;

import edu.ntnu.jonathhl.idatt2001.Client;
import javafx.fxml.FXMLLoader;

/**
 * Factory class dedicated to loading fxml-files
 *
 * @author jonathhl
 */
public class FXMLLoaderFactory {

    // Creating a private constructor to hide the public one
    private FXMLLoaderFactory() {
    }

    /**
     * Method to load a fxml-file
     * 
     * @param name
     *            parameter to take the file name, the only input the method needs when called.
     * 
     * @return returns a path to the entered filename.
     */
    public static FXMLLoader getFXMLLoader(String name) {
        var path = String.format("/fxml/%s.fxml", name);
        return new FXMLLoader(Client.class.getResource(path));
    }
}
