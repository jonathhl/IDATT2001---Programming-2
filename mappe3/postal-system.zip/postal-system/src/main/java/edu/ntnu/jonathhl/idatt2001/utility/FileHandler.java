package edu.ntnu.jonathhl.idatt2001.utility;

import edu.ntnu.jonathhl.idatt2001.factory.DialogFactory;
import edu.ntnu.jonathhl.idatt2001.model.ZipInfo;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/**
 * Reads the file containing the registry on postal info.
 *
 * @author jonathhl
 */
public class FileHandler {

    // Creating a temporary arraylist to contain file info for other classes to retrieve
    List<ZipInfo> tempList = new ArrayList<>();

    public File getFile() {
        // File path
        var file = new File("src/main/resources/Postnummerregister-ansi.txt");
        return file;
    }

    /**
     * Method to read the file containing the complete list of Zip codes in Norway.
     *
     * @return returns a temporary list containing all entries.
     *
     * @throws IOException
     *             if file can not be accessed, or similar.
     */
    public List<ZipInfo> readFile() throws IOException {

        // The try with resource parentheses contains code to prevent the reading of the file to stop on very large
        // files.
        // It should now read and add every object however long the list is.
        try (var bufferedReader = new BufferedReader(
                new InputStreamReader(new FileInputStream(getFile()), StandardCharsets.UTF_8))) {
            bufferedReader.lines().forEach(l -> {
                String[] columnLine = l.split("\t");
                String postalCode = columnLine[0];
                String postalArea = columnLine[1];
                String municipalityCode = columnLine[2];
                String municipalityName = columnLine[3];
                String category = columnLine[4];
                try {
                    tempList.add(new ZipInfo(postalArea, postalCode, municipalityCode, municipalityName, category));
                } catch (Exception e) {
                    e.printStackTrace();
                }
            });
        } catch (Exception e) {
            var content = String.format("Error: %s", e.getMessage());
            DialogFactory.getOKDialog("Ooops", "Something went wrong", content).show();
            e.printStackTrace();
        }
        return tempList;
    }

    public List<ZipInfo> getList() {
        return tempList;
    }
}
