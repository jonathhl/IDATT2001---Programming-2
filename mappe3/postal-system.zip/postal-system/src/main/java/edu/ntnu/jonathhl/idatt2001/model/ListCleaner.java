package edu.ntnu.jonathhl.idatt2001.model;

import edu.ntnu.jonathhl.idatt2001.factory.DialogFactory;
import edu.ntnu.jonathhl.idatt2001.utility.FileHandler;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Class dedicated to cleaning up the list.
 *
 * @author jonathhl
 */
public class ListCleaner {

    ObservableList<ZipInfo> originalList;
    ArrayList<ZipInfo> cleanedList = new ArrayList<>();
    FileHandler fileHandler = new FileHandler();

    /**
     * Method cleans up the list that {@link FileHandler} created, looks for duplicates and other illegal objects. For
     * example, an object with less than 4 digits in the postal code and municipality code.
     * 
     * @return a cleaned up list.
     */
    public List<ZipInfo> cleanup() {
        try {
            originalList = FXCollections.observableArrayList(fileHandler.readFile());
            for (ZipInfo object : originalList) {
                if (!cleanedList.contains(object)) {
                    if (object.getPostalCode().length() == 4 && object.getMunicipalityCode().length() == 4) {
                        cleanedList.add(object);
                    }
                }
            }
            return cleanedList;

        } catch (IOException e) {
            var content = String.format("Error: %s", e.getMessage());
            DialogFactory.getOKDialog("Ooops", "Something went wrong", content).show();
        }
        return cleanedList;
    }
}
