package edu.ntnu.jonathhl.idatt2001;

import edu.ntnu.jonathhl.idatt2001.factory.FXMLLoaderFactory;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

/**
 * Client class, loads GUI and sets the scene of the application
 *
 * @author jonathhl
 */
public class Client extends Application {

    private static final String WINDOW_TITLE = "PostalSystem";
    private static final int WINDOW_MIN_WIDTH = 800;
    private static final int WINDOW_MIN_HEIGHT = 600;

    @Override
    public void start(Stage stage) throws IOException {
        var fxmlLoader = FXMLLoaderFactory.getFXMLLoader("PostalRegistry");
        var scene = new Scene(fxmlLoader.load());
        stage.setScene(scene);

        stage.setTitle(WINDOW_TITLE);
        stage.setWidth(WINDOW_MIN_WIDTH);
        stage.setHeight(WINDOW_MIN_HEIGHT);

        stage.show();
    }

    public static void main(String[] args) {
        launch();
    }
}
